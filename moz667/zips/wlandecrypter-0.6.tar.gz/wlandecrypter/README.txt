wlandecrypter
*************
Generates a dictionary from a bssid and its essid.
author: nilp0inter2k6_at_gmail.com 
source: http://code.google.com/p/wlandecrypter/ 

Para compilar:
--------------

$ make

Despues logeate como root e instalalo con el siguiente comando:

# make install

o

$ sudo make install



uso: 
----
wlandecrypter <bssid> <essid> [output file] 


